-- MySQL dump 10.13  Distrib 8.0.31, for Win64 (x86_64)
--
-- Host: localhost    Database: proyectofinal
-- ------------------------------------------------------
-- Server version	8.0.31

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `administradores`
--

DROP TABLE IF EXISTS `administradores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `administradores` (
  `id_admin` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_admin`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `administradores`
--

LOCK TABLES `administradores` WRITE;
/*!40000 ALTER TABLE `administradores` DISABLE KEYS */;
INSERT INTO `administradores` VALUES (1,'Sergio Lopez','SRL1980@outlook.mx','4dmin#1980','2024-05-15 02:59:03');
/*!40000 ALTER TABLE `administradores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `id_cliente` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `correo` varchar(50) NOT NULL,
  `num_telefono` varchar(15) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'Jared Jacob Rojas Barrón','jaredrojas@gmail.com','3389675534','Avenida Juarez #34','2024-05-15 02:57:09'),(2,'Alma Veronica Macias Lozano','AlmaVML@outlook.mx','3319695234','Lopez Mateos #2024','2024-05-15 02:57:09'),(3,'Jareli Rojas Barron','Jareli1992@hotmail.com','3325991264','Calle Hidalgo #379','2024-05-15 02:57:09'),(4,'Cristhian Torres','CTGutierrez@outlook.com','3315401350','Tesistan #123','2024-05-15 02:57:09');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientesproductos`
--

DROP TABLE IF EXISTS `clientesproductos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientesproductos` (
  `id_cliente` int NOT NULL,
  `id_producto` int NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_cliente`,`id_producto`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `clientesproductos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `clientesproductos_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientesproductos`
--

LOCK TABLES `clientesproductos` WRITE;
/*!40000 ALTER TABLE `clientesproductos` DISABLE KEYS */;
INSERT INTO `clientesproductos` VALUES (1,1,'2024-05-15 04:04:58'),(1,5,'2024-05-15 04:04:58'),(2,2,'2024-05-15 04:04:58'),(2,3,'2024-05-15 04:04:58'),(3,4,'2024-05-15 04:04:58'),(4,1,'2024-05-15 04:04:58'),(4,3,'2024-05-15 04:04:58');
/*!40000 ALTER TABLE `clientesproductos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `estatuspedido`
--

DROP TABLE IF EXISTS `estatuspedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `estatuspedido` (
  `id_estatus` int NOT NULL AUTO_INCREMENT,
  `estatus` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_estatus`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `estatuspedido`
--

LOCK TABLES `estatuspedido` WRITE;
/*!40000 ALTER TABLE `estatuspedido` DISABLE KEYS */;
INSERT INTO `estatuspedido` VALUES (1,'En proceso','2024-05-15 02:56:30'),(2,'Por enviar','2024-05-15 02:56:30'),(3,'Listo para recoger en tienda','2024-05-15 02:56:30'),(4,'Enviado','2024-05-15 02:56:30'),(5,'Entregado','2024-05-15 02:56:33');
/*!40000 ALTER TABLE `estatuspedido` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventario`
--

DROP TABLE IF EXISTS `inventario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventario` (
  `id_inventario` int NOT NULL AUTO_INCREMENT,
  `precio_total` varchar(15) NOT NULL,
  `cantidad_productos` varchar(15) NOT NULL,
  `fecha` date NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `id_producto` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_inventario`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `inventario_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventario`
--

LOCK TABLES `inventario` WRITE;
/*!40000 ALTER TABLE `inventario` DISABLE KEYS */;
INSERT INTO `inventario` VALUES (1,'$359900','10 unidades','2024-05-15','Bodega principal',1,'2024-05-15 03:25:08'),(2,'$7800000','1200 unidades','2024-05-15','Bodega principal',2,'2024-05-15 03:25:59'),(3,'$3045000','350 unidades','2024-05-15','Bodega principal',3,'2024-05-15 03:26:37'),(4,'$89568','32 unidades','2024-05-15','Bodega principal',4,'2024-05-15 03:27:41'),(5,'$431760','120 unidades','2024-05-15','Bodega principal',5,'2024-05-15 03:28:11');
/*!40000 ALTER TABLE `inventario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `metodopago`
--

DROP TABLE IF EXISTS `metodopago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `metodopago` (
  `id_pago` int NOT NULL AUTO_INCREMENT,
  `tarjeta` varchar(16) NOT NULL,
  `efectivo` varchar(15) NOT NULL,
  `id_tipo_pago` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `paypal` varchar(15) NOT NULL,
  PRIMARY KEY (`id_pago`),
  KEY `id_tipo_pago` (`id_tipo_pago`),
  CONSTRAINT `metodopago_ibfk_1` FOREIGN KEY (`id_tipo_pago`) REFERENCES `tipopago` (`id_tipo_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `metodopago`
--

LOCK TABLES `metodopago` WRITE;
/*!40000 ALTER TABLE `metodopago` DISABLE KEYS */;
INSERT INTO `metodopago` VALUES (1,'No','Si',1,'2024-05-15 03:06:53','No'),(2,'Si','No',2,'2024-05-15 03:07:24','No'),(3,'No','No',3,'2024-05-15 03:07:35','Si');
/*!40000 ALTER TABLE `metodopago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pedidos`
--

DROP TABLE IF EXISTS `pedidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pedidos` (
  `id_pedido` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `cantidad` int NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `fecha_compra` date NOT NULL,
  `fecha_entrega` date NOT NULL,
  `id_producto` int DEFAULT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_estatus` int DEFAULT NULL,
  `id_metodo_pago` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_pedido`),
  KEY `id_producto` (`id_producto`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_estatus` (`id_estatus`),
  KEY `id_metodo_pago` (`id_metodo_pago`),
  CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`),
  CONSTRAINT `pedidos_ibfk_2` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `pedidos_ibfk_3` FOREIGN KEY (`id_estatus`) REFERENCES `estatuspedido` (`id_estatus`),
  CONSTRAINT `pedidos_ibfk_4` FOREIGN KEY (`id_metodo_pago`) REFERENCES `metodopago` (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pedidos`
--

LOCK TABLES `pedidos` WRITE;
/*!40000 ALTER TABLE `pedidos` DISABLE KEYS */;
INSERT INTO `pedidos` VALUES (1,'Pedido Jared',1,'Avenida Javier Mina','2024-03-29','2024-04-09',1,1,1,1,'2024-05-15 03:33:55'),(2,'Pedido Alma',2,'Avenida Avenida Vallarta','2024-01-15','2024-01-27',2,2,3,3,'2024-05-15 03:38:49'),(3,'Pedido Jareli',1,'Lopez Mateos','2024-02-28','2024-03-10',3,3,5,3,'2024-05-15 03:40:51');
/*!40000 ALTER TABLE `pedidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id_producto` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `cantidad` varchar(15) NOT NULL,
  `precio_unitario` varchar(15) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `id_proveedor` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_producto`),
  KEY `id_proveedor` (`id_proveedor`),
  CONSTRAINT `productos_ibfk_1` FOREIGN KEY (`id_proveedor`) REFERENCES `proveedores` (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'Celular Samsung A54','100 Unidades','$3599 pesos','Telefono gama media color blanco con 16 GB de RAM',4,'2024-05-15 02:57:41'),(2,'Celular XPERIA','1200 Unidades','$6500 pesos','Telefono gama alta con 16 GB de RAM y una camara de 128 megapixeles',1,'2024-05-15 02:57:41'),(3,'Pantalla Panasonic','350 Unidades','$8700 pesos','Pantalla de 50 pulgadas resolución 4k',2,'2024-05-15 02:57:41'),(4,'Celular Samsung A30','32 Unidades','$2799 pesos','Telefono gama baja con 4 GB de RAM y una camara de 16 megapixeles',4,'2024-05-15 02:57:41'),(5,'Pantalla LG','120 Unidades','$3598 pesos','Pantalla de 27 pulgadas con una resolución FULL HD nitida',3,'2024-05-15 02:57:41');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `id_proveedor` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `telefono` varchar(15) NOT NULL,
  `email` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_proveedor`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'Sony','Calle Providencia #23','3325678800','sonyelectronics@gmail.com','2024-05-15 02:56:52'),(2,'Panasonic','Colonia Americana #345','3355672800','panasonic@gmail.com','2024-05-15 02:56:52'),(3,'LG','Avenida Juarez $662','3374692602','lgelectronics@gmail.com','2024-05-15 02:56:52'),(4,'Samsung','Lopez Mateos #899','3324382212','samsung@gmail.com','2024-05-15 02:56:52');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `proveedoryproductos_view`
--

DROP TABLE IF EXISTS `proveedoryproductos_view`;
/*!50001 DROP VIEW IF EXISTS `proveedoryproductos_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `proveedoryproductos_view` AS SELECT 
 1 AS `Nombre del Proveedor`,
 1 AS `Dirección`,
 1 AS `Teléfono`,
 1 AS `Correo`,
 1 AS `Nombre del Producto`,
 1 AS `Cantidad`,
 1 AS `Precio x Pieza`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `resenas`
--

DROP TABLE IF EXISTS `resenas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `resenas` (
  `id_resena` int NOT NULL AUTO_INCREMENT,
  `id_cliente` int DEFAULT NULL,
  `fecha_resena` varchar(15) NOT NULL,
  `calificacion` varchar(15) NOT NULL,
  `id_producto` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_resena`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `resenas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `resenas_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resenas`
--

LOCK TABLES `resenas` WRITE;
/*!40000 ALTER TABLE `resenas` DISABLE KEYS */;
INSERT INTO `resenas` VALUES (1,3,'2024-04-13','5 estrellas',3,'2024-05-15 03:44:15');
/*!40000 ALTER TABLE `resenas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ticketproductos`
--

DROP TABLE IF EXISTS `ticketproductos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticketproductos` (
  `id_ticket` int NOT NULL,
  `id_producto` int NOT NULL,
  `cantidad` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ticket`,`id_producto`),
  KEY `id_producto` (`id_producto`),
  CONSTRAINT `ticketproductos_ibfk_1` FOREIGN KEY (`id_ticket`) REFERENCES `tickets` (`id_ticket`),
  CONSTRAINT `ticketproductos_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticketproductos`
--

LOCK TABLES `ticketproductos` WRITE;
/*!40000 ALTER TABLE `ticketproductos` DISABLE KEYS */;
INSERT INTO `ticketproductos` VALUES (1,1,1,'2024-05-15 04:05:45'),(2,2,2,'2024-05-15 04:05:45'),(2,3,1,'2024-05-15 04:05:45'),(3,4,3,'2024-05-15 04:05:45'),(4,5,1,'2024-05-15 04:05:45');
/*!40000 ALTER TABLE `ticketproductos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id_ticket` int NOT NULL AUTO_INCREMENT,
  `precio_total` varchar(15) NOT NULL,
  `cantidad_productos` varchar(15) NOT NULL,
  `fecha` date NOT NULL,
  `id_cliente` int DEFAULT NULL,
  `id_metodo_pago` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_ticket`),
  KEY `id_cliente` (`id_cliente`),
  KEY `id_metodo_pago` (`id_metodo_pago`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`),
  CONSTRAINT `tickets_ibfk_2` FOREIGN KEY (`id_metodo_pago`) REFERENCES `metodopago` (`id_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
INSERT INTO `tickets` VALUES (1,'$3599','1 unidad','2024-05-15',1,1,'2024-05-15 03:09:59'),(2,'$13000','2 unidad','2024-02-10',2,3,'2024-05-15 03:11:14'),(3,'$10794','3 unidad','2024-02-10',4,2,'2024-05-15 03:12:59'),(4,'$8700','1 unidad','2023-09-15',3,3,'2024-05-15 03:17:58'),(5,'$2799','1 unidad','2024-01-29',1,3,'2024-05-15 03:19:06');
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary view structure for view `ticketsconclientes_view`
--

DROP TABLE IF EXISTS `ticketsconclientes_view`;
/*!50001 DROP VIEW IF EXISTS `ticketsconclientes_view`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `ticketsconclientes_view` AS SELECT 
 1 AS `Precio total`,
 1 AS `Cantidad de productos`,
 1 AS `Fecha de compra`,
 1 AS `Numero de Cliente`,
 1 AS `Nombre del cliente`,
 1 AS `Telefono`*/;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `tipopago`
--

DROP TABLE IF EXISTS `tipopago`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipopago` (
  `id_tipo_pago` int NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_tipo_pago`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipopago`
--

LOCK TABLES `tipopago` WRITE;
/*!40000 ALTER TABLE `tipopago` DISABLE KEYS */;
INSERT INTO `tipopago` VALUES (1,'Efectivo','2024-05-15 02:53:50'),(2,'Tarjeta Credito o debito','2024-05-15 02:53:50'),(3,'PayPal','2024-05-15 02:53:50');
/*!40000 ALTER TABLE `tipopago` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `proveedoryproductos_view`
--

/*!50001 DROP VIEW IF EXISTS `proveedoryproductos_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `proveedoryproductos_view` AS select `p`.`nombre` AS `Nombre del Proveedor`,`p`.`direccion` AS `Direcci�n`,`p`.`telefono` AS `Tel�fono`,`p`.`email` AS `Correo`,`pr`.`nombre` AS `Nombre del Producto`,`pr`.`cantidad` AS `Cantidad`,`pr`.`precio_unitario` AS `Precio x Pieza` from (`proveedores` `p` join `productos` `pr` on((`p`.`id_proveedor` = `pr`.`id_proveedor`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `ticketsconclientes_view`
--

/*!50001 DROP VIEW IF EXISTS `ticketsconclientes_view`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `ticketsconclientes_view` AS select `t`.`precio_total` AS `Precio total`,`t`.`cantidad_productos` AS `Cantidad de productos`,`t`.`fecha` AS `Fecha de compra`,`c`.`id_cliente` AS `Numero de Cliente`,`c`.`nombre` AS `Nombre del cliente`,`c`.`num_telefono` AS `Telefono` from (`tickets` `t` join `clientes` `c` on((`t`.`id_cliente` = `c`.`id_cliente`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-17 10:36:15
